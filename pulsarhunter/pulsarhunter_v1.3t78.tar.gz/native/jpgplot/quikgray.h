void quikgray(float*dat,int nx,int ny,int nxx);
